/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tsilberm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/27 13:53:55 by tsilberm          #+#    #+#             */
/*   Updated: 2025/02/27 17:46:29 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_print_line(int l[])
{
	while (l[3] < 58)
	{
		if (l[0] == l[2] && l[1] == l[3])
		{
			l[3]++;
			continue ;
		}
		if (!(l[0] >= l[2] && l[1] > l[3]))
		{
			ft_putchar(l[0]);
			ft_putchar(l[1]);
			ft_putchar(' ');
			ft_putchar(l[2]);
			ft_putchar(l[3]);
			if (!(l[0] == 57 && l[1] == 56 && l[2] == 57 && l[3] == 57))
			{
				ft_putchar(',');
				ft_putchar(' ');
			}
		}
		l[3]++;
	}
}

void	ft_print_comb2(void)
{
	int	loop[4];

	loop[0] = 48;
	while (loop[0] < 58)
	{
		loop[1] = 48;
		while (loop[1] < 58)
		{
			loop[2] = loop[0];
			while (loop[2] < 58)
			{
				loop[3] = 48;
				ft_print_line(loop);
				loop[2]++;
			}
			loop[1]++;
		}
		loop[0]++;
	}
}
