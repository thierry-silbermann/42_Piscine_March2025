/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush03.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tsilberm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/01 12:42:20 by tsilberm          #+#    #+#             */
/*   Updated: 2025/03/02 14:52:39 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c);

void	ft_display_line(int x, char a, char b, char c)
{
	int	i;

	i = 0;
	if (x >= 1)
	{
		ft_putchar(a);
		i++;
	}
	while (i < (x - 1))
	{
		ft_putchar(b);
		i++;
	}
	if (x >= 2)
	{
		ft_putchar(c);
	}
	ft_putchar('\n');
}

void	rush(int x, int y)
{
	int	i;

	i = 0;
	if (x < 0 || y < 1)
	{
		write(2, "Error! Need number greater than 0 for x or 1 for y\n", 51);
		return ;
	}
	if (y >= 1 && x >= 0)
	{
		ft_display_line(x, 'A', 'B', 'C');
		i++;
	}
	while (i < y - 1 && x >= 1)
	{
		ft_display_line(x, 'B', ' ', 'B');
		i++;
	}
	if (y >= 2 && x >= 1)
	{
		ft_display_line(x, 'A', 'B', 'C');
	}
	return ;
}
