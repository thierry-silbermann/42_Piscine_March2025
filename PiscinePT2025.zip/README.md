C00 |  70/100 | ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: OK | ex07: Nothing turned in | ex08: Nothing turned in
C01 | 100/100 |  ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: OK | ex07: OK | ex08: OK
C02 |   85/100 | ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: OK | ex07: OK | ex08: OK | ex09: OK | ex10: OK | ex11: KO | ex12: Nothing turned in
C03 |  75/100 | ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: KO
C04 |  70/100 | ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: KO | ex05: KO
C05 | 100/100 | ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: OK | ex07: OK | ex08: OK
C06 | 100/100 | ex00: OK | ex01: OK | ex02: OK | ex03: OK
C07 |  60/100 | ex00: OK | ex01: OK | ex02: OK | ex03: KO | ex04: Nothing turned in | ex05: Nothing turned in
C08 |  70/100 | ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: Test 1 KO
C09 | 100/100 | ex00: OK | ex01: OK | ex02: OK
C10 |
C11 |
C12 |
C13 |

C Piscine Shell 00 | 95/100 | ex00: OK | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: OK | ex07: OK | ex08: OK | ex09: KO
C Piscine Shell 01 | 70/100 | ex01: OK | ex02: OK | ex03: OK | ex04: OK | ex05: OK | ex06: OK | ex07: KO | ex08: OK


C Piscine Rush 00 | 0 but working
C Piscine Rush 01 | 0 but missing valgrind check and spaces in displaying input
C Piscine Rush 02 | Not finished

C Piscine Exam 00    |  70/100
C Piscine Exam 01    | 100/100
C Piscine Exam 02    | Not here
C Piscine Final Exam | 
