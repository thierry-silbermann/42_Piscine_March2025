#!/bin/sh
(find . -type d && find . -type f) | wc -l | sed 's/ //g'
