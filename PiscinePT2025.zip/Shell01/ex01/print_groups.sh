#!/bin/sh
groups $FT_USER | awk -F': ' '{if (NF>1) print $2; else print $1}' | sed 's/ /,/g' | tr -d '\n'
