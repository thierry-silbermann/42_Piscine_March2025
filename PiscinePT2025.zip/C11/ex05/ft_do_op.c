/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_do_op.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tsilberm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/18 17:47:22 by tsilberm          #+#    #+#             */
/*   Updated: 2025/03/19 18:29:27 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"

void	ft_putstr(char *str)
{
	while (*str)
	{
		write(1, str, 1);
		str++;
	}
}

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	ft_do_op(int value1, int value2, char *op, int *flag)
{
	char	operator;

	if (ft_strlen(op) != 1)
		return (0);
	operator = op[0];
	if (operator == '+')
		return (add(value1, value2));
	else if (operator == '-')
		return (subtract(value1, value2));
	else if (operator == '*')
		return (multiply(value1, value2));
	else if (operator == '/')
		return (divide(value1, value2, flag));
	else if (operator == '%')
		return (modulo(value1, value2, flag));
	return (0);
}

int	main(int argc, char *argv[])
{
	char	*operator;
	int		res;
	int		error_flag;

	if (argc != 4)
	{
		return (0);
	}
	error_flag = 0;
	operator = argv[2];
	res = ft_do_op(ft_atoi(argv[1]), ft_atoi(argv[3]), operator, &error_flag);
	if (!error_flag)
	{
		ft_putnbr(res);
		ft_putstr("\n");
	}
	return (0);
}
