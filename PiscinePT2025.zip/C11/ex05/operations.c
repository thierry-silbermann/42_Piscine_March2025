/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   operations.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tsilberm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/18 17:48:17 by tsilberm          #+#    #+#             */
/*   Updated: 2025/03/18 19:03:34 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_header.h"

int	add(int a, int b)
{
	return (a + b);
}

int	subtract(int a, int b)
{
	return (a - b);
}

int	multiply(int a, int b)
{
	return (a * b);
}

int	divide(int a, int b, int *flag)
{
	if (b == 0)
	{
		*flag = 1;
		ft_putstr("Stop : division by zero\n");
		return (0);
	}
	return (a / b);
}

int	modulo(int a, int b, int *flag)
{
	if (b == 0)
	{
		*flag = 1;
		ft_putstr("Stop : modulo by zero\n");
		return (0);
	}
	return (a % b);
}
