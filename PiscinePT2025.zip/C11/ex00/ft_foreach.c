/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_foreach.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tsilberm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/18 17:21:01 by tsilberm          #+#    #+#             */
/*   Updated: 2025/03/19 19:00:28 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_foreach(int *tab, int length, void (*f)(int))
{
	int	i;

	i = 0;
	while (i < length)
	{
		f(tab[i]);
		i++;
	}
}
/*
void	print_number(int nb)
{
	printf("%d\n", nb);
}

int	main(void)
{
	int numbers[] = {1, 2, 3, 4, 5};
	ft_foreach(numbers, 5, print_number);
	return (0);
}*/
