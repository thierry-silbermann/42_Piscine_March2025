/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_map.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tsilberm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/18 17:22:24 by tsilberm          #+#    #+#             */
/*   Updated: 2025/03/19 19:09:55 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int	*ft_map(int *tab, int length, int (*f)(int))
{
	int	i;
	int	*new_tab;

	i = 0;
	new_tab = (int *)malloc(sizeof(int) * length);
	while (i < length)
	{
		new_tab[i] = f(tab[i]);
		i++;
	}
	return (new_tab);
}
/*
int	square(int x)
{
	return (x * x);
}

int	main(void)
{
	int i;
	int tab[] = {1, 2, 3, 4, 5};
	int *result;
	result = ft_map(tab, 5, square);
	i = 0;
	while (i < 5)
	{
		printf("%d ", result[i]);
		i++;
	}
	free(result);
}*/
