/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tsilberm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/18 17:32:20 by tsilberm          #+#    #+#             */
/*   Updated: 2025/03/20 19:21:07 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_is_sort(int *tab, int length, int (*f)(int, int))
{
	int	i;
	int	asc;
	int	desc;

	i = 0;
	asc = 1;
	desc = 1;
	if (length < 2)
	{
		return (1);
	}
	if (!tab || !f)
		return (0);
	while (i < length - 1)
	{
		if (f(tab[i], tab[i + 1]) > 0)
			asc = 0;
		if (f(tab[i], tab[i + 1]) < 0)
			desc = 0;
		i++;
	}
	return (asc || desc);
}
/*
int	ascending(int a, int b)
{
	return (a - b);
}

int	main()
{
	int arr[] = {0, 1, 2, 3};
	int result = ft_is_sort(arr, 4, ascending);
	printf("Sorted -> %d\n", result);

	int arr2[] = {1, 0, 3, 4};
	int result2 = ft_is_sort(arr2, 4, ascending);
	printf("Not sorted -> %d\n", result2);

	int arr3[] = {5, 4, 3, 2, 1}; 
        int result3 = ft_is_sort(arr3, 5, ascending);
        printf("Sorted -> %d\n", result3);
}*/
