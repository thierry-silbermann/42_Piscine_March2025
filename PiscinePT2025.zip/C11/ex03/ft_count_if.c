/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_count_if.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tsilberm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/18 17:28:58 by tsilberm          #+#    #+#             */
/*   Updated: 2025/03/20 19:03:14 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_count_if(char **tab, int length, int (*f)(char*))
{
	int	i;
	int	count;

	i = 0;
	count = 0;
	if (!tab || !f)
		return (0);
	while (i < length)
	{
		if (f(tab[i]))
			count++;
		i++;
	}
	return (count);
}
/*
int	starts_with_a(char *str)
{
	return (str[0] == 'a');
}

int main(void)
{
	char *words[] = {"apple", "banana", "avocado", "grape", "apricot"};
	int count = ft_count_if(words, 5, starts_with_a);
	printf("Count of words starting with 'a': %d\n", count);
	return (0);
}*/
