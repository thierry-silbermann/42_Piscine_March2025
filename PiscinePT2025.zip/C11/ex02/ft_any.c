/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_any.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tsilberm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/18 17:26:54 by tsilberm          #+#    #+#             */
/*   Updated: 2025/03/19 19:13:20 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_any(char **tab, int (*f)(char*))
{
	while (*tab != 0)
	{
		if (f(*(tab++)))
			return (1);
	}
	return (0);
}
/*
int	is_not_empty(char *str)
{
	return (str[0] != '\0');
}

int	main(void)
{
	char *tab1[] = {"Hello", "World", "", NULL};
	printf("Test 1: %d (Expected: 1)\n", ft_any(tab1, is_not_empty));

	char *tab2[] = {"", "", "", NULL};
	printf("Test 2: %d (Expected: 0)\n", ft_any(tab2, is_not_empty));
}*/
