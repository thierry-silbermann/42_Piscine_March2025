/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tsilberm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/03 16:42:03 by tsilberm          #+#    #+#             */
/*   Updated: 2025/03/04 13:51:02 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while (i < n)
	{
		if (s1[i] < s2[i])
			return (-1);
		if (s1[i] > s2[i])
			return (1);
		if (s1[i] == '\0')
			break ;
		i++;
	}
	return (0);
}
/*
int main()
{
    char s1[] = "Hell";
    char s2[] = "Hello";
    unsigned int n = 2;

    int result = ft_strncmp(s1, s2, n);

    if (result == 0)
        printf("Strings are equal.\n");
    else if (result < 0)
        printf("s1 is less than s2.\n");
    else
        printf("s1 is greater than s2.\n");

    return 0;
}*/
