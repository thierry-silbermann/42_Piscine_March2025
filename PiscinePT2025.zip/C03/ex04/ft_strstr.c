/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tsilberm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/04 13:59:33 by tsilberm          #+#    #+#             */
/*   Updated: 2025/03/04 14:14:48 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strstr(char *str, char *to_find)
{
	char	*s1;
	char	*s2;

	if (*to_find == '\0')
		return (str);
	while (*str != '\0')
	{
		s1 = str;
		s2 = to_find;
		while (*s1 != '\0' && *s2 != '\0' && *s1 == *s2)
		{
			s1++;
			s2++;
		}
		if (*s2 == '\0')
			return (str);
		str++;
	}
	return (NULL);
}
/*
int main() {
	char str[] = "Hello, world!";
	char to_find[] = "world";

	char *result = ft_strstr(str, to_find);
    
	if (result != NULL)
		printf("Found substring: %s\n", result);
	else
		printf("Substring not found.\n");
	return (0);
}*/
