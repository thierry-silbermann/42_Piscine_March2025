/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tsilberm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/04 14:17:09 by tsilberm          #+#    #+#             */
/*   Updated: 2025/03/04 14:56:29 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	i;
	unsigned int	j;
	unsigned int	src_len;

	i = 0;
	j = 0;
	src_len = 0;
	if (size == 0)
		return (0);
	while (dest[i] != '\0' && i < size)
		i++;
	while (src[src_len] != '\0')
		src_len++;
	while (src[i] && (i + j < size - 1))
	{
		dest[i + j] = src[j];
		j++;
	}
	if (i != size)
		dest[i + j] = '\0';
	return (i + src_len);
}
/*
int	main()
{
	char dest[20] = "Hello";
	char src[] = " World!";
	unsigned int size = 15;
	unsigned int result = ft_strlcat(dest, src, size);
	printf("Resulting string: %s\n", dest);
	printf("Total length: %u\n", result);

	char dest2[20] = "Hello";
	char src2[] = " World!";
	unsigned int size2 = 5;
	unsigned int result2 = ft_strlcat(dest2, src2, size2);
	printf("Resulting string: %s\n", dest2);
	printf("Total length: %u\n", result2);

	char dest3[20] = "Hello";
	char src3[] = " World!";
	unsigned int size3 = 0;
	unsigned int result3 = ft_strlcat(dest3, src3, size3);
	printf("Resulting string: %s\n", dest3);
	printf("Total length: %u\n", result3);

	return (0);
}*/
