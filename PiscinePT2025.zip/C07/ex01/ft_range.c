/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tsilberm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/11 13:27:34 by tsilberm          #+#    #+#             */
/*   Updated: 2025/03/11 13:38:46 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int	*ft_range(int min, int max)
{
	int	i;
	int	*tab;

	i = 0;
	if (min >= max)
		return (NULL);
	tab = (int *) malloc(sizeof(*tab) * (max - min));
	while (min < max)
	{
		tab[i] = min;
		min++;
		i++;
	}
	return (tab);
}
/*
int	main(void)
{
	int	*tab;
	int 	i;

	i = 0;
	tab = ft_range(10, 15);
	while (tab[i])
	{
		printf("%d\n", tab[i]);
		i++;
	}

	tab = ft_range(5, 2);
	i = 0;
	if (tab)
	{
		while (tab[i])
        	{
                	printf("%d\n", tab[i]);
                	i++;
       		}
	}
}*/
