/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tsilberm <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/11 13:45:58 by tsilberm          #+#    #+#             */
/*   Updated: 2025/03/13 11:37:27 by tsilberm         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

int	ft_size_to_allocate(int size, char **strs, char *sep)
{
	int	i;
	int	total_len;

	total_len = 0;
	i = 0;
	while (i < size)
	{
		total_len += ft_strlen(strs[i]);
		if (i < size - 1)
			total_len += ft_strlen(sep);
		i++;
	}
	return (total_len + 1);
}

void	ft_copy(char *result, char *str, int *pos)
{
	int	i;

	i = 0;
	while (str[i])
	{
		result[*pos] = str[i];
		(*pos)++;
		i++;
	}
}

char	*ft_concatenate(int size, char **strs, char *sep, char *result)
{
	int	i;
	int	j;
	int	pos;

	i = 0;
	pos = 0;
	while (i < size)
	{
		ft_copy(result, strs[i], &pos);
		if (i < size - 1)
		{
			j = 0;
			while (sep[j])
			{
				result[pos] = sep[j];
				j++;
				pos++;
			}
		}
		i++;
	}
	result[pos] = '\0';
	return (result);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*result;

	if (size == 0)
		return (malloc(1));
	result = malloc(ft_size_to_allocate(size, strs, sep));
	if (!result)
		return (NULL);
	return (ft_concatenate(size, strs, sep, result));
}
/*
int	main(void)
{
	char *strs[] = {"Hello", "world", "how", "are", "you"};
	char *sep = " / ";
	char *result = ft_strjoin(5, strs, sep);
	printf("%s\n", result);
	free(result);

	result = ft_strjoin(0, strs, sep);
	printf("%s\n", result);
	free(result);
	return (0);
}*/
