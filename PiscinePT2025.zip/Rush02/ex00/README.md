You can use

> make

that will compile the projet


And then you can run the program

> ./rush-02 42

> ./rush-02 -53

> ./rush-02 567.2

> ./rush-02 16542
