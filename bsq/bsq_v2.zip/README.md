make fclean
make

valgrind --leak-check=full ./bsq map_example map_example
gdb --args bsq map_example map_example


TODO:
- Check memory freeing
- Include case with read (no argument)
- Create new map to check
- In main.c/parse_first_line, we need to take into account an input of not just one digit but a number, also check that we are getting printable char after the number



File updated:
- Makefile
	two lines
- solve.c
	- all
- main.c
	- one line in main
- read_input.c
	- all
- ft_header.h
	- struct answer + 2 lines 



mini_map
3.ox
....
..o.
....

xx..
xxo.
....
