#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

#define MAX_BUFFER 1024

int	ft_isdigit(char c)
{
	return (c >= '0' && c <= '9');
}

int	main(void)
{
	int	i;
	int	j;
	char	buffer[MAX_BUFFER];
	int	bytesRead;
	int	numLines;
	int	line;

	bytesRead = read(0, buffer, MAX_BUFFER - 1);
	if (bytesRead <= 0)
	{
		perror("read");
		return 1;
	}

	buffer[bytesRead] = '\0';

	/* Extract the number from the input */
	numLines = 0;
	i = 0;
	while (ft_isdigit(buffer[i]))
	{
		numLines = numLines * 10 + (buffer[i] - '0');
		i++;
	}
	// Read the next 3 characters
	char specialChars[4] = {0}; // Ensure null termination
	j = 0;
	while (j < 3 && buffer[i] != '\0')
	{
		specialChars[j] = buffer[i];
		j++;
		i++;
	}

	// Print the extracted values
	printf("Number of lines to read: %d\n", numLines);
	printf("Special characters: %s\n", specialChars);

	line = 0;
	// Read the specified number of lines from the user
	while (line < numLines)
	{
		int lineBytes = read(0, buffer, MAX_BUFFER - 1);
		if (lineBytes <= 0)
		{
			perror("read");
			return (1);
		}
		buffer[lineBytes] = '\0'; // Null-terminate the string
		printf("Line %d: %s", line + 1, buffer);
		line++;
	}
	return (0);
}
