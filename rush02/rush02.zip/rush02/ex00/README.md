Working function that check the input and print the line by line string of the dictionary

"cc -Wall -Werror -Wextra main_test.c ft_header.h check_input.c ft_atoi.c dict_processing.c"
